./configure --host=arm-linux-gnueabihf CXX=arm-linux-androideabi-g++ CXXFLAGS=-static CC=arm-linux-androideabi-gcc CFLAGS=--sysroot=/home/snq/rowboat-android/wl18xx-snq/android-ndk-r9d/platforms/android-17/arch-arm/

# ./configure   CC=arm-linux-androideabi-gcc  CFLAGS=--sysroot=/home/snq/rowboat-android/wl18xx-snq/android-ndk-r9d/platforms/android-17/arch-arm/
